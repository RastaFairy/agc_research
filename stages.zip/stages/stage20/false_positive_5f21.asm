
/tmp/libSceAgcDriver.sprx:	file format elf64-x86-64

Disassembly of section PT_LOAD#0:

0000000000000000 <PT_LOAD#0>:
    5e7e: 4c 8d 05 83 4a 01 00         	lea	r8, [rip + 0x14a83]     # 0x1a908 <PT_LOAD#0+0x1a908>
    5e85: 41 b9 00 00 ad de            	mov	r9d, 0xdead0000
    5e8b: 41 8b 70 0c                  	mov	esi, dword ptr [r8 + 0xc]
    5e8f: c7 00 00 61 03 c0            	mov	dword ptr [rax], 0xc0036100
    5e95: 40 f6 c6 01                  	test	sil, 0x1
    5e99: be 00 00 ad de               	mov	esi, 0xdead0000
    5e9e: 48 0f 44 f2                  	cmove	rsi, rdx
    5ea2: 83 e1 fc                     	and	ecx, -0x4
    5ea5: 89 f5                        	mov	ebp, esi
    5ea7: 48 89 f3                     	mov	rbx, rsi
    5eaa: 83 e5 fc                     	and	ebp, -0x4
    5ead: 48 c1 eb 20                  	shr	rbx, 0x20
    5eb1: 89 68 04                     	mov	dword ptr [rax + 0x4], ebp
    5eb4: 48 8d ae 00 80 00 00         	lea	rbp, [rsi + 0x8000]
    5ebb: 48 81 c6 00 90 00 00         	add	rsi, 0x9000
    5ec2: 89 58 08                     	mov	dword ptr [rax + 0x8], ebx
    5ec5: 48 c7 40 0c 00 00 00 00      	mov	qword ptr [rax + 0xc], 0x0
    5ecd: c7 40 14 00 5f 03 c0         	mov	dword ptr [rax + 0x14], 0xc0035f00
    5ed4: 89 eb                        	mov	ebx, ebp
    5ed6: 41 89 f3                     	mov	r11d, esi
    5ed9: 48 c1 ed 20                  	shr	rbp, 0x20
    5edd: 48 c1 ee 20                  	shr	rsi, 0x20
    5ee1: 83 e3 fc                     	and	ebx, -0x4
    5ee4: 41 83 e3 fc                  	and	r11d, -0x4
    5ee8: 89 58 18                     	mov	dword ptr [rax + 0x18], ebx
    5eeb: 89 68 1c                     	mov	dword ptr [rax + 0x1c], ebp
    5eee: 48 c7 40 20 00 00 00 00      	mov	qword ptr [rax + 0x20], 0x0
    5ef6: c7 40 28 00 5e 03 c0         	mov	dword ptr [rax + 0x28], 0xc0035e00
    5efd: 44 89 58 2c                  	mov	dword ptr [rax + 0x2c], r11d
    5f01: 89 70 30                     	mov	dword ptr [rax + 0x30], esi
    5f04: 48 be 00 37 03 c0 00 02 00 40	movabs	rsi, 0x40000200c0033700
    5f0e: 48 c7 40 34 00 00 00 00      	mov	qword ptr [rax + 0x34], 0x0
    5f16: 48 89 70 3c                  	mov	qword ptr [rax + 0x3c], rsi
    5f1a: 89 48 44                     	mov	dword ptr [rax + 0x44], ecx
    5f1d: 48 8d 48 50                  	lea	rcx, [rax + 0x50]
    5f21: 44 89 50 48                  	mov	dword ptr [rax + 0x48], r10d
    5f25: c7 40 4c 00 00 00 00         	mov	dword ptr [rax + 0x4c], 0x0
    5f2c: 48 29 f9                     	sub	rcx, rdi
    5f2f: 48 83 c1 e4                  	add	rcx, -0x1c
    5f33: 48 c1 e9 02                  	shr	rcx, 0x2
    5f37: 89 4f 18                     	mov	dword ptr [rdi + 0x18], ecx
    5f3a: 41 8b 48 0c                  	mov	ecx, dword ptr [r8 + 0xc]
    5f3e: c7 40 50 00 61 03 c0         	mov	dword ptr [rax + 0x50], 0xc0036100
    5f45: f6 c1 01                     	test	cl, 0x1
    5f48: b9 00 00 00 80               	mov	ecx, 0x80000000
    5f4d: 4c 0f 44 ca                  	cmove	r9, rdx
    5f51: ba 03 80 01 80               	mov	edx, 0x80018003
    5f56: 0f 44 ca                     	cmove	ecx, edx
    5f59: 44 89 ca                     	mov	edx, r9d
    5f5c: 4c 89 ce                     	mov	rsi, r9
    5f5f: 83 e2 fc                     	and	edx, -0x4
    5f62: 48 c1 ee 20                  	shr	rsi, 0x20
    5f66: 89 50 54                     	mov	dword ptr [rax + 0x54], edx
    5f69: 49 8d 91 00 80 00 00         	lea	rdx, [r9 + 0x8000]
