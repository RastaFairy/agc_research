
/tmp/libSceAgcDriver.sprx:	file format elf64-x86-64

Disassembly of section PT_LOAD#0:

0000000000000000 <PT_LOAD#0>:
    6200: fc                           	cld
    6201: 48 be 00 37 03 c0 00 02 00 40	movabs	rsi, 0x40000200c0033700
    620b: c7 00 00 61 03 c0            	mov	dword ptr [rax], 0xc0036100
    6211: 44 89 68 04                  	mov	dword ptr [rax + 0x4], r13d
    6215: 44 89 70 08                  	mov	dword ptr [rax + 0x8], r14d
    6219: 48 c7 40 0c 00 00 00 00      	mov	qword ptr [rax + 0xc], 0x0
    6221: c7 40 14 00 5f 03 c0         	mov	dword ptr [rax + 0x14], 0xc0035f00
    6228: 44 89 40 18                  	mov	dword ptr [rax + 0x18], r8d
    622c: 44 89 48 1c                  	mov	dword ptr [rax + 0x1c], r9d
    6230: 48 c7 40 20 00 00 00 00      	mov	qword ptr [rax + 0x20], 0x0
    6238: c7 40 28 00 5e 03 c0         	mov	dword ptr [rax + 0x28], 0xc0035e00
    623f: 44 89 78 2c                  	mov	dword ptr [rax + 0x2c], r15d
    6243: 89 50 30                     	mov	dword ptr [rax + 0x30], edx
    6246: 48 c7 40 34 00 00 00 00      	mov	qword ptr [rax + 0x34], 0x0
    624e: c5 f8 10 05 5a 9f 00 00      	vmovups	xmm0, xmmword ptr [rip + 0x9f5a] # 0x101b0 <PT_LOAD#0+0x101b0>
    6256: 48 89 70 3c                  	mov	qword ptr [rax + 0x3c], rsi
    625a: 89 48 44                     	mov	dword ptr [rax + 0x44], ecx
    625d: 48 8b 4c 24 f8               	mov	rcx, qword ptr [rsp - 0x8]
    6262: 89 48 48                     	mov	dword ptr [rax + 0x48], ecx
    6265: 48 8d 48 50                  	lea	rcx, [rax + 0x50]
    6269: c7 40 4c 00 00 00 00         	mov	dword ptr [rax + 0x4c], 0x0
    6270: 48 29 f9                     	sub	rcx, rdi
    6273: 48 83 c1 e4                  	add	rcx, -0x1c
    6277: 48 c1 e9 02                  	shr	rcx, 0x2
    627b: 89 4f 18                     	mov	dword ptr [rdi + 0x18], ecx
    627e: c7 40 50 00 61 03 c0         	mov	dword ptr [rax + 0x50], 0xc0036100
    6285: 44 89 68 54                  	mov	dword ptr [rax + 0x54], r13d
    6289: 44 89 70 58                  	mov	dword ptr [rax + 0x58], r14d
    628d: 48 c7 40 5c 00 00 00 00      	mov	qword ptr [rax + 0x5c], 0x0
    6295: c7 40 64 00 5f 03 c0         	mov	dword ptr [rax + 0x64], 0xc0035f00
    629c: 44 89 40 68                  	mov	dword ptr [rax + 0x68], r8d
    62a0: 44 89 48 6c                  	mov	dword ptr [rax + 0x6c], r9d
    62a4: 48 c7 40 70 00 00 00 00      	mov	qword ptr [rax + 0x70], 0x0
    62ac: c7 40 78 00 5e 03 c0         	mov	dword ptr [rax + 0x78], 0xc0035e00
    62b3: 44 89 78 7c                  	mov	dword ptr [rax + 0x7c], r15d
    62b7: 89 90 80 00 00 00            	mov	dword ptr [rax + 0x80], edx
    62bd: 48 c7 80 84 00 00 00 00 00 00 00     	mov	qword ptr [rax + 0x84], 0x0
    62c8: c5 f8 11 80 8c 00 00 00      	vmovups	xmmword ptr [rax + 0x8c], xmm0
    62d0: c7 80 9c 00 00 00 01 00 00 00	mov	dword ptr [rax + 0x9c], 0x1
    62da: 48 05 a0 00 00 00            	add	rax, 0xa0
    62e0: 5b                           	pop	rbx
    62e1: 41 5c                        	pop	r12
    62e3: 41 5d                        	pop	r13
    62e5: 41 5e                        	pop	r14
    62e7: 41 5f                        	pop	r15
    62e9: 5d                           	pop	rbp
    62ea: c3                           	ret
    62eb: cc                           	int3
    62ec: cc                           	int3
    62ed: cc                           	int3
    62ee: cc                           	int3
    62ef: cc                           	int3
    62f0: 85 d2                        	test	edx, edx
    62f2: 48 b8 00 00 ad de 0f 00 00 00	movabs	rax, 0xfdead0000
    62fc: ba 03 80 01 80               	mov	edx, 0x80018003
    6301: b9 00 00 00 80               	mov	ecx, 0x80000000
    6306: c7 07 00 61 03 c0            	mov	dword ptr [rdi], 0xc0036100
    630c: 48 0f 45 c6                  	cmovne	rax, rsi
    6310: 0f 45 ca                     	cmovne	ecx, edx
    6313: 89 c2                        	mov	edx, eax
    6315: 48 89 c6                     	mov	rsi, rax
    6318: 83 e2 fc                     	and	edx, -0x4
    631b: 48 c1 ee 20                  	shr	rsi, 0x20
    631f: 89 57 04                     	mov	dword ptr [rdi + 0x4], edx
    6322: 48 8d 90 00 80 00 00         	lea	rdx, [rax + 0x8000]
    6329: 89 77 08                     	mov	dword ptr [rdi + 0x8], esi
    632c: 48 05 00 90 00 00            	add	rax, 0x9000
    6332: 48 c7 47 0c 00 00 00 00      	mov	qword ptr [rdi + 0xc], 0x0
    633a: c7 47 14 00 5f 03 c0         	mov	dword ptr [rdi + 0x14], 0xc0035f00
    6341: 89 d6                        	mov	esi, edx
    6343: 48 c1 ea 20                  	shr	rdx, 0x20
    6347: 83 e6 fc                     	and	esi, -0x4
    634a: 89 77 18                     	mov	dword ptr [rdi + 0x18], esi
    634d: 89 c6                        	mov	esi, eax
    634f: 48 c1 e8 20                  	shr	rax, 0x20
    6353: 89 57 1c                     	mov	dword ptr [rdi + 0x1c], edx
    6356: 48 c7 47 20 00 00 00 00      	mov	qword ptr [rdi + 0x20], 0x0
    635e: c7 47 28 00 5e 03 c0         	mov	dword ptr [rdi + 0x28], 0xc0035e00
    6365: 48 ba 00 28 01 c0 03 80 01 91	movabs	rdx, -0x6efe7ffc3ffed800
    636f: 83 e6 fc                     	and	esi, -0x4
    6372: 89 77 2c                     	mov	dword ptr [rdi + 0x2c], esi
    6375: 89 47 30                     	mov	dword ptr [rdi + 0x30], eax
    6378: 48 8d 47 48                  	lea	rax, [rdi + 0x48]
    637c: 48 c7 47 34 00 00 00 00      	mov	qword ptr [rdi + 0x34], 0x0
    6384: 48 89 57 3c                  	mov	qword ptr [rdi + 0x3c], rdx
    6388: 89 4f 44                     	mov	dword ptr [rdi + 0x44], ecx
    638b: c3                           	ret
    638c: cc                           	int3
    638d: cc                           	int3
    638e: cc                           	int3
    638f: cc                           	int3
    6390: c5 f8 10 05 e8 9d 00 00      	vmovups	xmm0, xmmword ptr [rip + 0x9de8] # 0x10180 <PT_LOAD#0+0x10180>
    6398: c5 f8 10 15 30 9e 00 00      	vmovups	xmm2, xmmword ptr [rip + 0x9e30] # 0x101d0 <PT_LOAD#0+0x101d0>
    63a0: c5 f8 10 0d 38 9e 00 00      	vmovups	xmm1, xmmword ptr [rip + 0x9e38] # 0x101e0 <PT_LOAD#0+0x101e0>
    63a8: 45 89 c2                     	mov	r10d, r8d
    63ab: 4d 89 c3                     	mov	r11, r8
    63ae: 48 b9 00 37 03 c0 00 02 10 46	movabs	rcx, 0x46100200c0033700
    63b8: 4c 8d 4f 18                  	lea	r9, [rdi + 0x18]
    63bc: 41 83 e0 f8                  	and	r8d, -0x8
    63c0: 48 8d 47 38                  	lea	rax, [rdi + 0x38]
    63c4: 48 89 4f 38                  	mov	qword ptr [rdi + 0x38], rcx
    63c8: 41 83 e2 fc                  	and	r10d, -0x4
    63cc: 49 c1 eb 20                  	shr	r11, 0x20
    63d0: 48 b9 00 00 00 00 00 49 06 c0	movabs	rcx, -0x3ff9b70000000000
    63da: 44 89 57 40                  	mov	dword ptr [rdi + 0x40], r10d
    63de: 44 89 5f 44                  	mov	dword ptr [rdi + 0x44], r11d
    63e2: 48 89 4f 48                  	mov	qword ptr [rdi + 0x48], rcx
    63e6: 48 b9 28 05 00 06 00 00 01 42	movabs	rcx, 0x4201000006000528
