# Next targets

1. Clasificar las funciones que reciben/registran contextos antes de las rutas `0x1820`, `0x45b0` y `0x1a30`.
2. Trazar referencias a la dirección de entrada `0x1a908 + index*0x78` mediante registros que sobrevivan a llamadas auxiliares.
3. Buscar stores indirectos a `+0x48` donde la base se derive de `0x1a908` sin aparecer como un displacement literal.
4. Sólo después atribuir nombre/semántica al callback y reconstruir su firma.
