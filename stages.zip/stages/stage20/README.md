# AGC PS5 Stage 20 — canonical SPRX callback-table audit

Fuente única: `libSceAgcDriver.sprx` extraído directamente de `proyecto_retroarch_ps5.zip`.

SHA-256: ver `SHA256.txt`.
Tamaño: 139680 bytes.

## Hallazgos

1. El binario canónico es ELF64 x86-64, FreeBSD ABI, con PT_LOAD de código que empieza en VA 0x0.
2. La tabla global usada por el dispatcher está realmente en VA `0x1a908`.
3. El dispatcher en `0x1820` hace `lea r15, [rip+...] -> 0x1a908`, usa `entry+0x48` como puntero de callback y avanza cada entrada con stride `0x78`.
4. La rutina de inicialización `0xd0` y su variante `0x160` escriben los campos `+0x50`, `+0x58`, `+0x68`, `+0x80`, `+0x88`, pero no escriben `+0x48`.
5. Los `mov ...,+0x48` encontrados en `0x5f21`, `0x6262` y `0x63e2` pertenecen a estructuras de command-buffer/estado locales, no a la tabla global `0x1a908`.
6. La rutina `0x45b0` confirma de forma independiente el consumo de la tabla: calcula `0x1a908+0x48`, itera con stride `0x78`, lee el puntero y lo llama.

## Conclusión

Seguimos sin tener una evidencia de escritura directa sobre `0x1a908 + index*0x78 + 0x48` en esta imagen canónica. Por tanto no se debe bautizar todavía el origen de ese callback ni inventar una API de registro.

La discrepancia `0x1a908` vs `0x1e908` de Stage 15 queda explicada como evidencia procedente de otra imagen/layout y no se reutiliza.
