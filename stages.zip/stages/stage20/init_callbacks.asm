
/tmp/libSceAgcDriver.sprx:	file format elf64-x86-64

Disassembly of section PT_LOAD#0:

0000000000000000 <PT_LOAD#0>:
      d0: 48 63 c7                     	movsxd	rax, edi
      d3: 48 8d 0d 2e a8 01 00         	lea	rcx, [rip + 0x1a82e]    # 0x1a908 <PT_LOAD#0+0x1a908>
      da: 48 8d 35 1f 0f 00 00         	lea	rsi, [rip + 0xf1f]      # 0x1000 <PT_LOAD#0+0x1000>
      e1: 48 ba 78 00 00 00 0e 00 01 00	movabs	rdx, 0x1000e00000078
      eb: c5 f8 57 c0                  	vxorps	xmm0, xmm0, xmm0
      ef: 48 8d 3d ca 3b 00 00         	lea	rdi, [rip + 0x3bca]     # 0x3cc0 <PT_LOAD#0+0x3cc0>
      f6: 48 6b c0 78                  	imul	rax, rax, 0x78
      fa: c5 fc 11 84 01 80 00 00 00   	vmovups	ymmword ptr [rcx + rax + 0x80], ymm0
     103: c5 fc 11 44 01 30            	vmovups	ymmword ptr [rcx + rax + 0x30], ymm0
     109: c5 fc 11 44 01 50            	vmovups	ymmword ptr [rcx + rax + 0x50], ymm0
     10f: c5 fc 11 44 01 70            	vmovups	ymmword ptr [rcx + rax + 0x70], ymm0
     115: 48 89 54 01 28               	mov	qword ptr [rcx + rax + 0x28], rdx
     11a: c6 44 01 35 ff               	mov	byte ptr [rcx + rax + 0x35], -0x1
     11f: 48 89 74 01 50               	mov	qword ptr [rcx + rax + 0x50], rsi
     124: 48 8d 35 05 19 00 00         	lea	rsi, [rip + 0x1905]     # 0x1a30 <PT_LOAD#0+0x1a30>
     12b: 48 89 7c 01 58               	mov	qword ptr [rcx + rax + 0x58], rdi
     130: 48 8d 3d a9 66 00 00         	lea	rdi, [rip + 0x66a9]     # 0x67e0 <PT_LOAD#0+0x67e0>
     137: 48 89 74 01 68               	mov	qword ptr [rcx + rax + 0x68], rsi
     13c: 48 8d 35 cd 66 00 00         	lea	rsi, [rip + 0x66cd]     # 0x6810 <PT_LOAD#0+0x6810>
     143: 48 89 bc 01 80 00 00 00      	mov	qword ptr [rcx + rax + 0x80], rdi
     14b: 48 89 b4 01 88 00 00 00      	mov	qword ptr [rcx + rax + 0x88], rsi
     153: c3                           	ret
     154: cc                           	int3
     155: cc                           	int3
     156: cc                           	int3
     157: cc                           	int3
     158: cc                           	int3
     159: cc                           	int3
     15a: cc                           	int3
     15b: cc                           	int3
     15c: cc                           	int3
     15d: cc                           	int3
     15e: cc                           	int3
     15f: cc                           	int3
     160: 55                           	push	rbp
     161: 48 89 e5                     	mov	rbp, rsp
     164: 48 8d 05 9d a7 01 00         	lea	rax, [rip + 0x1a79d]    # 0x1a908 <PT_LOAD#0+0x1a908>
     16b: 83 b8 a0 00 00 00 00         	cmp	dword ptr [rax + 0xa0], 0x0
     172: 74 24                        	je	0x198 <PT_LOAD#0+0x198>
     174: 48 8b 0d 65 3f 01 00         	mov	rcx, qword ptr [rip + 0x13f65] # 0x140e0 <PT_LOAD#0+0x140e0>
     17b: 48 8d 3d bf f5 00 00         	lea	rdi, [rip + 0xf5bf]     # 0xf741 <PT_LOAD#0+0xf741>
     182: be 30 00 00 00               	mov	esi, 0x30
     187: ba 01 00 00 00               	mov	edx, 0x1
     18c: e8 df a9 00 00               	call	0xab70 <PT_LOAD#0+0xab70>
     191: b8 06 00 6d 8a               	mov	eax, 0x8a6d0006
     196: 5d                           	pop	rbp
     197: c3                           	ret
     198: 48 8d 15 61 0e 00 00         	lea	rdx, [rip + 0xe61]      # 0x1000 <PT_LOAD#0+0x1000>
     19f: 48 b9 78 00 00 00 0e 00 01 00	movabs	rcx, 0x1000e00000078
     1a9: c5 f8 57 c0                  	vxorps	xmm0, xmm0, xmm0
     1ad: c5 fc 11 80 80 00 00 00      	vmovups	ymmword ptr [rax + 0x80], ymm0
     1b5: c5 fc 11 40 30               	vmovups	ymmword ptr [rax + 0x30], ymm0
     1ba: c5 fc 11 40 50               	vmovups	ymmword ptr [rax + 0x50], ymm0
     1bf: c5 fc 11 40 70               	vmovups	ymmword ptr [rax + 0x70], ymm0
     1c4: 48 8d 35 f5 3a 00 00         	lea	rsi, [rip + 0x3af5]     # 0x3cc0 <PT_LOAD#0+0x3cc0>
     1cb: c5 f8 57 c0                  	vxorps	xmm0, xmm0, xmm0
     1cf: 48 89 48 28                  	mov	qword ptr [rax + 0x28], rcx
     1d3: c6 40 35 ff                  	mov	byte ptr [rax + 0x35], -0x1
     1d7: 48 89 50 50                  	mov	qword ptr [rax + 0x50], rdx
     1db: 48 8d 15 4e 18 00 00         	lea	rdx, [rip + 0x184e]     # 0x1a30 <PT_LOAD#0+0x1a30>
     1e2: 48 89 70 58                  	mov	qword ptr [rax + 0x58], rsi
     1e6: 48 8d 35 f3 65 00 00         	lea	rsi, [rip + 0x65f3]     # 0x67e0 <PT_LOAD#0+0x67e0>
     1ed: 48 89 50 68                  	mov	qword ptr [rax + 0x68], rdx
     1f1: 48 8d 15 18 66 00 00         	lea	rdx, [rip + 0x6618]     # 0x6810 <PT_LOAD#0+0x6810>
     1f8: 48 89 b0 80 00 00 00         	mov	qword ptr [rax + 0x80], rsi
     1ff: 48 89 90 88 00 00 00         	mov	qword ptr [rax + 0x88], rdx
     206: c7 80 a0 00 00 00 01 00 00 00	mov	dword ptr [rax + 0xa0], 0x1
     210: c5 f8 11 80 a4 00 00 00      	vmovups	xmmword ptr [rax + 0xa4], xmm0
     218: 31 c0                        	xor	eax, eax
     21a: 5d                           	pop	rbp
     21b: c3                           	ret
     21c: cc                           	int3
     21d: cc                           	int3
     21e: cc                           	int3
     21f: cc                           	int3
